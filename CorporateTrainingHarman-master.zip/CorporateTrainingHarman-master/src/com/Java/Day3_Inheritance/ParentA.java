package com.Java.Day3_Inheritance;

public class ParentA 
{
	
	public void color()
	{
		System.out.println("Red");
	}

}
