package com.Java.Day1;

public class FirstCode 
{
	
	
	public static void main(String args[])
	{
		
		System.out.println("Hello All");
		
		//reusable script we can create using static method
		MethodDemo.show();
	}

	
}
