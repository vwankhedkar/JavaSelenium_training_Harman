package com.Java.Day2;

import com.Java.Day1.AccessModifier;

//import com.Java.Day1.AccessModifier;

public class DifferentPackage {

	public static void main(String[] args) 
	{
		AccessModifier a1=new AccessModifier();
		System.out.println(a1.name);
		

	}

}
