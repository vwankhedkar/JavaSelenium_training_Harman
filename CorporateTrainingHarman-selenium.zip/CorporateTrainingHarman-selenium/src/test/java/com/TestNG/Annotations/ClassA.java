package com.TestNG.Annotations;

import org.testng.annotations.Test;

public class ClassA {
  @Test
  public void testCase1() 
  {
	  System.out.println("ClassA test case1");
  }
  
  @Test
  public void testCase2() 
  {
	  System.out.println("ClassA test case2");
  }
  
  @Test
  public void testCase3() 
  {
	  System.out.println("ClassA test case3");
  }
}
