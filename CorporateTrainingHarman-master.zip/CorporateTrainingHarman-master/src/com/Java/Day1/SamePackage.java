package com.Java.Day1;

public class SamePackage {

	public static void main(String[] args)
	{

		AccessModifier a1=new AccessModifier();
		System.out.println(a1.id);
		System.out.println(a1.name);

		
	}

}
