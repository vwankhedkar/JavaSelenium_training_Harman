package com.Java.Day3_DataAbstraction;

public interface USMA extends WHO
{
	
	void nero();
	void cardio();
	

}
