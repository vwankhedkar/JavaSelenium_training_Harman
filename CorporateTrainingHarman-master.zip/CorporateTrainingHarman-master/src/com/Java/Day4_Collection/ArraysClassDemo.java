package com.Java.Day4_Collection;

import java.util.Arrays;
import java.util.List;

public class ArraysClassDemo {

	public static void main(String[] args)
	{
		//Arrays is class from Object class
		
		List<Integer> l1=Arrays.asList(90,67,55,10);
		
		List<String> loc=Arrays.asList("Pune","Mumbai");
		
		
		//Array is Object in java-static data structure
		
		int arr[]= {99,78};
		
		//ArrayList is class in Collection interface
		
	}

}
