package com.Java.Day3_Inheritance;

public class Parent
{
	int pid=101;
	
	public void parentIncome()
	{
		System.out.println("Parent income is : $17000");
	}
	
	public Parent()
	{
		System.out.println("Parent Constructor calling!");
	}

}
