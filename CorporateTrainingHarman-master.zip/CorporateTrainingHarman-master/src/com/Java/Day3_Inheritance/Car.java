package com.Java.Day3_Inheritance;

public class Car extends Vehical
{
	
	
	
	public void price()
	{
		System.out.println("Car....5L");
	}
	
	
	public void start()
	{
		System.out.println("Car.....start()");
	}
	
	public void refule()
	{
		System.out.println("Car.....refule()");
	}
	
	public void stop()
	{
		System.out.println("Car.....stop()");
	}

}
