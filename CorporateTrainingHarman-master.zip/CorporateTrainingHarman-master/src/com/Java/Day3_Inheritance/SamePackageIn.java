package com.Java.Day3_Inheritance;

public class SamePackageIn {

	public static void main(String[] args) 
	{
		AccessModifierIn  a1=new AccessModifierIn ();
		System.out.println(a1.id);
		System.out.println(a1.name);
		System.out.println(a1.acno);
		
		
	}

}
