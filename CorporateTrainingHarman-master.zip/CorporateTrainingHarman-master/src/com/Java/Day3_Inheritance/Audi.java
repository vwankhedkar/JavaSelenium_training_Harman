package com.Java.Day3_Inheritance;

public class Audi extends Car // Hierarchical inheritance
{
	
	public void autoGear()
	{
		System.out.println("Audi.....autoGear()");
	}

}
