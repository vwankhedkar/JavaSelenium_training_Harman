package com.Java.Day3_Inheritance;

public class Vehical
{

	public void breakFeature()
	{
		System.out.println("Vehical.......break()");
	}
	
	
}
