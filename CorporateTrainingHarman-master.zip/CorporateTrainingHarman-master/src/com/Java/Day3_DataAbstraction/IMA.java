package com.Java.Day3_DataAbstraction;

public interface IMA extends WHO
{
	
	void physio();
	void dental();
	

}
