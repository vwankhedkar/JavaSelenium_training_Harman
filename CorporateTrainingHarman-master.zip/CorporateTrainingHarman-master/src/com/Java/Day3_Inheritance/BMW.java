package com.Java.Day3_Inheritance;

public class BMW extends Car//- single level 
{
	
	@Override
	public void price()
	{
		System.out.println("BMW.......50L");
	}
	
	
	public void autEngine()
	{
		System.out.println("BMW.....autoEngine()");
	}

}
