package com.Java.Day3_DataAbstraction;

public interface WHO 
{
	void covid19Test();

}
