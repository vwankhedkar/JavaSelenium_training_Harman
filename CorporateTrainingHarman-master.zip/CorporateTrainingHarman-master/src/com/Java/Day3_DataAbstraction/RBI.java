package com.Java.Day3_DataAbstraction;

public interface RBI 
{
	/*
	 * By default all the methods are public and abstract
	 * By default data is final and static
	 * 100% abstraction 
	 */
	
	int x=100;
	
	void deposite();
	void withdraw();
	void rateOfInterest();
	
	
	
	

}
